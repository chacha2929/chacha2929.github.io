import React from 'react';

// 함수형 컨포넌트(뷰만 다룰때)
// 리액트 라이프사이클, state를 사용할수 없다.

const Test = () => {
    
    return ( 
        <h1>React Component</h1>
    
    )
}

export default Test; 