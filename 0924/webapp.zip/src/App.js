import React from 'react'; //사용할수 있게 설정
//리액트 컴포넌트는 항상 단일 구조여야 한다.
//리액트에서 클래스를 만들떄는 class가 아니라 className으로 작성해야 한다
//리액트 JSX문법에서는 if나  for문법을 사용할수 없다. 대신 삼향연산자는 가능하다.
//(조건) ?  참일떄 실행 : 거짓일떄 실행


//{} 자바스크립트 변수로 인식

class App extends React.Component {
    
    onPopup(){ //함수
        alert('a');
    }
    
    render(){ 
        
        let text = 'React';
        let check = 'ture';
        
        return(
            <div>
               { check ? <h1>React Ture</h1> : <h1>React false</h1> }
                <h2 className="title" onClick={this.onPopup}>Welcome to {text}{/*text*/} World</h2>
            </div>
        )
    }
}

export default App; //내보내기