//var React = require('react');
import React from 'react';
import ReactDom from 'react-dom';
//import './index.css'
import App from './App'; //App.js 컴포넌트를 불러옴
import Test from './Test';
import Main from './Main';

//Dom(document)

//endpoint
//ReactDom.render(<h1>Hello React App</h1>,document.getElementById('root'));

//ReactDom.render(<App/>,document.getElementById('root')); 

//ReactDom.render(<Test/>,document.getElementById('root')); 

ReactDom.render(<Main />,document.getElementById('root'));