import React from 'react';

const Ptag = ({bb}) => { //함수형 컴포넌트
    
    return(
        <div>부모 컴포넌트가 준 데이터는 {bb}다.</div>
    )
}

export default Ptag;