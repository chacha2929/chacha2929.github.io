import React from 'react';

const Child = (props) => {
    
    return(
        <div>{props.num}</div>
    )
}

export default Child;