import React, {Component} from 'react';

class Content extends Component {
    
    render(){
        
        return(
            <div>{this.props.text} Content</div>
        )
    }
}

export default Content;